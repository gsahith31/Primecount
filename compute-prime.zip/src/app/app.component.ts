import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'compute-prime';
  start = 0;
  end = 0;
  count: number = -1;
  timeTaken = 0;
  ipdetails:any = null;
  id = -1;
  constructor(private http: HttpClient) {

  }

  getCountOfPrimeNos() {
    var startDate = new Date();
    let count = 0;
    let isPrime;
    if (this.start < 2) {
      this.start = 2;
    }
    for (let i = this.start; i <= this.end; i++) {
      isPrime = 1;
      for (let j = 2; j <= i / 2; j++) {
        if (i % j == 0) {
          isPrime = 0;
          break;
        }
      }
      if (isPrime == 1) {
        count++;
      }
    }
    var endDate = new Date();
    this.timeTaken = endDate.getTime() - startDate.getTime();
    this.count = count;
  }

  getIp() {
    this.http.get('https://api.freegeoip.app/json/?apikey=3b96d0a0-8e77-11ec-a31c-51c4984d339a').subscribe((data) => {
      console.log(data);
      this.ipdetails = data;
    })
  }
}
